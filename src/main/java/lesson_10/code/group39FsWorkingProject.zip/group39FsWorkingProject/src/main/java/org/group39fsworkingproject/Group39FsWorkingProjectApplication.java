package org.group39fsworkingproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group39FsWorkingProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(Group39FsWorkingProjectApplication.class, args);
    }

}
