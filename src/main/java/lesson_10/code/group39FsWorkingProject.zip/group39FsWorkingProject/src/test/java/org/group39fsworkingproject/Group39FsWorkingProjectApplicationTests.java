package org.group39fsworkingproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Group39FsWorkingProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
