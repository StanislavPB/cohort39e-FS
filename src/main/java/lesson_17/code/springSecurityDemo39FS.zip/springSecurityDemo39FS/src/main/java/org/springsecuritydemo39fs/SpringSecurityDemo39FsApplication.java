package org.springsecuritydemo39fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityDemo39FsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityDemo39FsApplication.class, args);
    }

}
