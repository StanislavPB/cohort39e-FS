
JWT (JSON Web Token) - строка header.payload.signature

1. Заголовок (header)

{
"alg" : "HS256",
"typ": "JWT"
}

Производится кодирование header в формате Base64Url

2. Полезная нагрузка (payload)

- registered claims:
  - subject (идентификатор пользователя)
  - issueTime - время выдачи токена
  - exp - срок действия токена

- public claims

- private claims

  Производится кодирование payload в формате Base64Url

3. Подпись (signature)

На сервере хранится "закрытый ключ" - некая "строка" / "ключ" с помощью которого производится следующие действия:
- берется созданный header
- берется созданный payload
- использую ключ header.payload шифруется по алгоритму, который указан в заголовке и получает некую signature

Далее все это собирается вместе в JWT : header.payload.signature