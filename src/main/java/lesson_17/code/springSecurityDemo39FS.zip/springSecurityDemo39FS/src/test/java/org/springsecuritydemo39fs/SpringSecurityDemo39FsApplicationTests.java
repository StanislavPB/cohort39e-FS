package org.springsecuritydemo39fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityDemo39FsApplicationTests {

    @Test
    void contextLoads() {
    }

}
