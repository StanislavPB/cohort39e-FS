package org.springsecuritydemo39fs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springsecuritydemo39fs.entity.MyUser;

import java.util.Optional;

public interface MyUserRepository extends JpaRepository<MyUser, Integer> {

    Optional<MyUser> findByLogin(String login);
}
