package org.jdbcexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLDbDemo {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        /*
        1) загрузить драйвер
        2) подключится к базе данных
        3) создание нужной таблицы и / или вставка данных в таблицу
        4) извлечение данных
        5) закрыть соединение (ресурс)

        DriverManager - позволяет подключиться к базе данных
        по указанному URL

        Также он загружает драйвер JDBC

        Регистрация драйвера в системе:
        1) Driver driver = new com.mysql.jdbc.Driver();
        DriverManager.registerDriver(driver);

        2) Class.forName("com.mysql.jdbc.Driver");

         */

        Class.forName("com.mysql.cj.jdbc.Driver");

        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/group39fs","root","root2023");

        if (connection.isClosed()) {
            System.out.println("Соединение закрыто");
        } else {
            System.out.println("Соединение установленно");
        }

        Statement statement = connection.createStatement();

        // создадим таблицу

        String sqlRequest = "CREATE TABLE employee (id INT PRIMARY KEY, name VARCHAR(255))";

        System.out.println("Таблица employee создана успешно? " + statement.execute(sqlRequest));



        // добавим данные в таблицу

        String sqlRequest1 = "INSERT INTO employee VALUES(1,'John')";
        String sqlRequest2 = "INSERT INTO employee VALUES(2,'Bill')";

        boolean result1 = statement.execute(sqlRequest1);
        System.out.println("Insert first data was success: " + result1);

        boolean result2 = statement.execute(sqlRequest2);
        System.out.println("Insert second data was success: " + result2);



        //-------------
        statement.close();
        connection.close();

    }
}
