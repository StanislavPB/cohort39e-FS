package org.jdbcexample;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DeveloperJdbcDemo {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        List<Developer> developers = new ArrayList<>();

        Connection connection = null;
        Statement statement = null;

        System.out.println("Registration driver...");
        Class.forName("com.mysql.cj.jdbc.Driver");

        System.out.println("Creating database connection ...");
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/group39fs","root","root2023");

        System.out.println("Execute statement ...");
        statement = connection.createStatement();

        // создать таблицу

        String sqlRequest = "CREATE TABLE developers (id INT PRIMARY KEY, name VARCHAR(255), speciality VARCHAR(255), salary INT)";
        statement.execute(sqlRequest);

        // вставляем данные в таблицу

        String sqlRequest1 = "INSERT INTO developers VALUES(1,'John','back-end developer', 5000)";
        String sqlRequest2 = "INSERT INTO developers VALUES(2,'Bill','front-end developer', 4500)";
        String sqlRequest3 = "INSERT INTO developers VALUES(3,'Robert','DevOps', 5500)";
        String sqlRequest4 = "INSERT INTO developers VALUES(4,'Olga','accounting', 2500)";
        String sqlRequest5 = "INSERT INTO developers VALUES(5,'Ruslan','Team lead', 7000)";

        statement.execute(sqlRequest1);
        statement.execute(sqlRequest2);
        statement.execute(sqlRequest3);
        statement.execute(sqlRequest4);
        statement.execute(sqlRequest5);

//------------------------------------------------------------------

        // получим данные из базы данных

        System.out.println("------------------------------------------------------------------");
        System.out.println("Receive data from database ...");

        ResultSet resultSet = statement.executeQuery("SELECT * FROM developers");

        while (resultSet.next()) {
            System.out.println("==========");
            int id = resultSet.getInt("id");
            String name = resultSet.getString("name");
            String speciality = resultSet.getString("speciality");
            int salary = resultSet.getInt("salary");

            Developer developer = new Developer(id,name,speciality,salary);

            System.out.println(developer);
            developers.add(developer);
        }

        System.out.println("===============");

        System.out.println("Наша коллекция разработчиков с данными из БД");
        for (Developer developer : developers){
            System.out.println(developer);
        }

        statement.close();
        connection.close();

    }
}
