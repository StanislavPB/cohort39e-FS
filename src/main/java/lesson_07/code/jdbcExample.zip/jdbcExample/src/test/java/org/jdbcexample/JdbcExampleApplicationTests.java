package org.jdbcexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
