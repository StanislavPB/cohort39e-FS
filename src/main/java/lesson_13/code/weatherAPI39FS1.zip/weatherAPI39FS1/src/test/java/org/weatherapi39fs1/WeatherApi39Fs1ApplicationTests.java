package org.weatherapi39fs1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherApi39Fs1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
