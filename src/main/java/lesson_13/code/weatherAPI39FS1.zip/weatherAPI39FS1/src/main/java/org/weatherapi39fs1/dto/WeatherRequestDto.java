package org.weatherapi39fs1.dto;

import lombok.Data;

@Data
public class WeatherRequestDto {
    private String latitude;
    private String longitude;


}
