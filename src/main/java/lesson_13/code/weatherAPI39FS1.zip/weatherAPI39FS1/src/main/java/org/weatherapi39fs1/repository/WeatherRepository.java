package org.weatherapi39fs1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.weatherapi39fs1.entity.WeatherDataEntity;

import java.util.Optional;

@Repository
public interface WeatherRepository extends JpaRepository<WeatherDataEntity, Integer> {
    Optional<WeatherDataEntity> findByLatitudeAndLongitude(String lat, String lon);

    Optional<WeatherDataEntity> findByLatitudeAndLongitudeOrderByCreateTimeDesc(String lat, String lon);

//    @Query("SELECT w FROM weather w WHERE w.latitude = :lat AND w.longitude = :lon ORDER BY w.createDate DESC")
//    Optional<WeatherDataEntity> findLatestByLatitudeAndLongitude(@Param("lat") String lat, @Param("lon") String lon)
//
}
