package org.weatherapi39fs1.service;

import org.weatherapi39fs1.dto.WeatherRequestDto;
import org.weatherapi39fs1.dto.WeatherResponseDto;

import java.net.MalformedURLException;
import java.net.URISyntaxException;

public interface WeatherDataServiceInterface {

    WeatherResponseDto getWeather(String lat, String lon) throws MalformedURLException, URISyntaxException;
}
