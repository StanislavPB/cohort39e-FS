package org.weatherapi39fs1.service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.weatherapi39fs1.dto.WeatherRequestDto;
import org.weatherapi39fs1.dto.WeatherResponseDto;
import org.weatherapi39fs1.entity.WeatherDataEntity;
import org.weatherapi39fs1.repository.WeatherRepository;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
@AllArgsConstructor
public class WeatherDataService implements WeatherDataServiceInterface{

    /**
     *
     * WeatherResponseDto getWeather(WeatherRequestDto request)
     *
     * Optional<WeatherDataEntity> getDataFromDatabase(String lat, String lon)
     *
     * WeatherResponseDto getDataFromApi(String lat, String lon)
     */


    private final WeatherRepository repository;
    private final Converter converter;
    private final OutWeatherApi outWeatherApi;

    private final Integer EXPIRATION_TIME = 10;


    @Override
    public WeatherResponseDto getWeather(String lat, String lon) throws MalformedURLException, URISyntaxException {

        Optional<WeatherDataEntity> dataEntityOptional = getFromDatabase(lat,lon);

        if (checkDatabaseRecord(dataEntityOptional)) {
            WeatherDataEntity currentWeatherFromDatabase = dataEntityOptional.get();
            WeatherResponseDto responseForClient = converter.fromEntityToDto(currentWeatherFromDatabase);
            return responseForClient;
        }

        WeatherDataEntity currentWeatherFromApi = getFromApi(lat, lon);

        repository.save(currentWeatherFromApi);

        WeatherResponseDto responseForClient = converter.fromEntityToDto(currentWeatherFromApi);

        return responseForClient;
    }


//    public WeatherResponseDto getWeatherShort(WeatherRequestDto request) {
//        return getFromDatabase(request.getLatitude(),request.getLongitude())
//                .filter(this::checkDatabaseRecord)
//                .map(converter::fromEntityToDto)
//                .orElseGet(() -> {
//                            WeatherDataEntity currentWeatherFromApi = getFromApi(request.getLatitude(), request.getLongitude());
//                            repository.save(currentWeatherFromApi);
//                            return converter.fromEntityToDto(currentWeatherFromApi);
//                        });
//
//    }


    //----------------------------------------------------------------------

    private Optional<WeatherDataEntity> getFromDatabase(String latitude, String longitude) {
        return repository.findByLatitudeAndLongitudeOrderByCreateTimeDesc(latitude, longitude);
    }


    private boolean checkDatabaseRecord(Optional<WeatherDataEntity> dataEntityOptional) {
        if (dataEntityOptional.isEmpty()) return false;
        WeatherDataEntity databaseRecord = dataEntityOptional.get();

        LocalDateTime createdTime = databaseRecord.getCreateTime();

        long duration = Duration.between(LocalDateTime.now(), createdTime).toMinutes();

        return duration <= EXPIRATION_TIME;

    }

    private WeatherDataEntity getFromApi(String latitude, String longitude) throws MalformedURLException, URISyntaxException {
        return outWeatherApi.receivedDataFromWeatherApi(latitude, longitude);
    }


}
