package org.weatherapi39fs1.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.weatherapi39fs1.dto.WeatherRequestDto;
import org.weatherapi39fs1.dto.WeatherResponseDto;
import org.weatherapi39fs1.service.WeatherDataServiceInterface;

import java.net.MalformedURLException;
import java.net.URISyntaxException;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class GetWeatherController {

    private final WeatherDataServiceInterface service;

    @GetMapping("/weather")
    public WeatherResponseDto getWeather(@RequestParam String lat, @RequestParam String lon) throws MalformedURLException, URISyntaxException {
        return service.getWeather(lat,lon);
    }
}
