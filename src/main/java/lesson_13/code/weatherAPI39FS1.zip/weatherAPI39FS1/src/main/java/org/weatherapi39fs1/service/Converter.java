package org.weatherapi39fs1.service;

import org.springframework.stereotype.Component;
import org.weatherapi39fs1.dto.WeatherResponseDto;
import org.weatherapi39fs1.entity.WeatherDataEntity;

import java.time.LocalDateTime;

@Component
public class Converter {

    WeatherResponseDto fromEntityToDto(WeatherDataEntity entity){
        WeatherResponseDto response = new WeatherResponseDto();
        response.setLatitude(entity.getLatitude());
        response.setLongitude(entity.getLongitude());
        response.setTemp(entity.getTemp());
        return response;
    }

    WeatherDataEntity fromDtoToEntity(WeatherResponseDto dto){
        WeatherDataEntity entity = new WeatherDataEntity();
        entity.setLatitude(dto.getLatitude());
        entity.setLongitude(dto.getLongitude());
        entity.setTemp(dto.getTemp());
        entity.setCreateTime(LocalDateTime.now());
        return entity;
    }
}
