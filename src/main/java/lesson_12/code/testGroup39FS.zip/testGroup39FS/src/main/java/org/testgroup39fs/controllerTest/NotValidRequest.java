package org.testgroup39fs.controllerTest;

public class NotValidRequest extends RuntimeException {
    public NotValidRequest(String message) {
        super(message);
    }
}
