package org.testgroup39fs.taxCalculator;

public interface CurrentYearProvider {
    int getYear();
}
