package org.testgroup39fs.salaryPayment;

public interface BankService {
    void makePayment(String employeeId, int salary);
}
