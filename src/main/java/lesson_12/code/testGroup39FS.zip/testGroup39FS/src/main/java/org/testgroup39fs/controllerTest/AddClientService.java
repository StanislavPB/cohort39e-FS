package org.testgroup39fs.controllerTest;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Service
@RequiredArgsConstructor
@Validated
public class AddClientService {

    private final ClientRepository repository;

    public Client addClient(@Valid Client client){
        return repository.save(client);
    }

}
