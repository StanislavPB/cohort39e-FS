package org.testgroup39fs.salaryPayment;

import java.util.List;

public interface EmployeeDB {

    List<Employee> getAllEmployees();
}
