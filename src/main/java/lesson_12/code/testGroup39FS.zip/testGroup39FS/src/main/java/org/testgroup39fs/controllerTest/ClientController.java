package org.testgroup39fs.controllerTest;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/clients")
@RequiredArgsConstructor
public class ClientController {

    private final AddClientService service;

    @PostMapping("/addNewClient")
    public ResponseEntity<Client> addNewClient(@RequestBody ClientRequestDto request){
        Client newClient = new Client();
        newClient.setName(request.getName());
        newClient.setEmail(request.getEmail());
        newClient = service.addClient(newClient);
        return new ResponseEntity<>(newClient,HttpStatus.CREATED);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handlerValidationException(MethodArgumentNotValidException exception){
        Map<String, Object> errors = new HashMap<>();
        exception.getBindingResult().getFieldErrors().forEach( error ->
                errors.put(error.getField(), error.getDefaultMessage()));

        return ResponseEntity.badRequest().body(Map.of("errors", errors));
    }

    @ExceptionHandler(NotValidRequest.class)
    public ResponseEntity<String> handlerVNotValidRequest(NotValidRequest exception){
        return ResponseEntity.badRequest().body(exception.getMessage());
    }


}
