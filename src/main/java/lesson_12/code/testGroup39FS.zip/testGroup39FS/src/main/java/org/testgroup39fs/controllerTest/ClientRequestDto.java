package org.testgroup39fs.controllerTest;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientRequestDto {

    @NotBlank(message = "Name must not be blank")
    @Size(min = 2, max = 50,message = "Name length must be between 2 and 50 characters.")
    private String name;

    @NotBlank(message = "Email must not be blank")
    @Email
    private String email;

}
