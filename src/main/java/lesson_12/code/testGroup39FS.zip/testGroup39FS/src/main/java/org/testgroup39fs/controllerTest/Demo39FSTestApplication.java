package org.testgroup39fs.controllerTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo39FSTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo39FSTestApplication.class, args);
    }
}
