package org.clientapp39fs.controller;

import lombok.RequiredArgsConstructor;
import org.clientapp39fs.dto.RequestDto;
import org.clientapp39fs.entity.Client;
import org.clientapp39fs.service.AddClientService;
import org.clientapp39fs.service.DeleteService;
import org.clientapp39fs.service.FindService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RequiredArgsConstructor
@RestController
@RequestMapping("/clients")
public class ClientController {

    private final AddClientService addClientService;
    private final FindService findService;
    private final DeleteService deleteService;

    /*
    localhost:8080/clients - get запрос

    localhost:8080/clients/addNew - post запрос

    localhost:8080/clients/3 get запрос, где 3 - это порядковый номер моего клиента и он может меняться
    по сути 3 - id

    localhost:8080/clients/findByName?clientName=James


    /clients/{id}/orders

    /api/v1/...

    www.company.com/pics/myphoto.html
    www.company.com/api/pics/myphoto/{id}
     */

    @PostMapping("/addNew")
    // localhost:8080/clients/addNew
    public Integer addNew(@RequestBody RequestDto requestDto){
        return addClientService.addClient(requestDto);
    }

    @GetMapping
    // localhost:8080/clients
    public List<Client> findAll(){
        return findService.findAll();
    }

    // localhost:8080/clients/id
    @GetMapping("/{clientId}")
    public Optional<Client> findById(@PathVariable(name = "clientId") Integer id){
        return findService.findById(id);
    }

    // localhost:8080/clients/findByName?clientName=James
    @GetMapping("/findByName")
    public List<Client> findByName(@RequestParam(value = "clientName") String name){
        return findService.findByName(name);
    }

//    //localhost:8080/clients/findByName/James
//    @GetMapping("/findByName/{name}")
//    public List<Client> findByName2(@PathVariable String name){
//        return findService.findByName(name);
//    }

    @GetMapping("/findByEmail")
    // localhost:8080/clients/findByEmail?email=James@company.com
    public Optional<Client> findByEmail(@RequestParam String email){
        return findService.findByEmail(email);
    }

    @DeleteMapping("/{id}")
    // localhost:8080/clients/{id}
    public boolean deleteClient(@PathVariable Integer id){
        return deleteService.deleteClient(id);
    }

}
