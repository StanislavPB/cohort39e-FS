package org.clientapp39fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientApp39FsApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClientApp39FsApplication.class, args);
    }

}
