package org.clientapp39fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientApp39FsApplicationTests {

    @Test
    void contextLoads() {
    }

}
