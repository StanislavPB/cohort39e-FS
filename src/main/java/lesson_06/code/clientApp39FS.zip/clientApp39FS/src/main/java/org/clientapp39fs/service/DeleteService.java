package org.clientapp39fs.service;

import lombok.RequiredArgsConstructor;
import org.clientapp39fs.repository.ClientRepository;
import org.springframework.stereotype.Service;


@RequiredArgsConstructor
@Service
public class DeleteService {

    private final ClientRepository repository;

    public boolean deleteClient(Integer id){

        boolean deleteResult = repository.delete(id);

        return deleteResult;

    }
}
