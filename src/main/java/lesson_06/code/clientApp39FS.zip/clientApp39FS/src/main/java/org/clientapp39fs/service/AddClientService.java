
package org.clientapp39fs.service;

import lombok.RequiredArgsConstructor;
import org.clientapp39fs.dto.RequestDto;
import org.clientapp39fs.entity.Client;
import org.clientapp39fs.repository.ClientRepository;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class AddClientService {

    private final ClientRepository repository;

    public Integer addClient(RequestDto request){
        Client newClient = new Client(0, request.getName(), request.getEmail(), request.getPhone());

        Integer idNewClient = repository.add(newClient);

        return idNewClient;
    }
}
