package org.demo39fsemail;

import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository repository;
    private final EmailService emailService;

    public void registerUser(String email) throws MessagingException {
//        User user = new User();
//        user.setEmail(email);
//        user.setConfirmationCode("code");
//        user.setConfirmed(false);
        /*

        UUID - universal unique identifier

        128-bit

        формат 8-4-4-4-12
        123a4567-e89d-12d3-efgh-456789012345
        UUID.randomUUID()

         */

        User user = User.builder()
                .email(email)
                .confirmationCode(UUID.randomUUID().toString())
                .isConfirmed(false)
                .build();

        repository.save(user);

        // отправка email с confirmationCode
        emailService.sendConfirmationEmailWithHTML(user);
    }

    public boolean confirmUser(String confirmationCode){
        Optional<User> userOptional = repository.findByConfirmationCode(confirmationCode);

        if (userOptional.isPresent()) {
        User user = userOptional.get();
        user.setConfirmed(true);
        repository.save(user);
        return true;
        }

        return false;

    }


}
