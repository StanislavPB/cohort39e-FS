package org.demo39fsemail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo39fsEmailApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo39fsEmailApplication.class, args);
    }

}
