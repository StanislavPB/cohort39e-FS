package org.demo39fsemail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo39fsEmailApplicationTests {

    @Test
    void contextLoads() {
    }

}
