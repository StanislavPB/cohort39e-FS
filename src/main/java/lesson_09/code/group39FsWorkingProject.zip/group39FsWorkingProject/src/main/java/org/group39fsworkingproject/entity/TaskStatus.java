package org.group39fsworkingproject.entity;

public enum TaskStatus {
    OPEN,
    CLOSE,
    PROGRESS
}
