package org.group39fsworkingproject.controller;

import lombok.RequiredArgsConstructor;
import org.group39fsworkingproject.dto.managerDto.ManagerCreateRequestDto;
import org.group39fsworkingproject.dto.managerDto.ManagerCreateResponseDto;
import org.group39fsworkingproject.dto.managerDto.ManagerResponseDto;
import org.group39fsworkingproject.entity.Manager;
import org.group39fsworkingproject.service.ManagerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/managers")
public class ManagerController {
    private final ManagerService service;

    @PostMapping
    public ManagerCreateResponseDto createNewManager(@RequestBody ManagerCreateRequestDto request){
        return service.createManager(request);
    }


    @GetMapping
    public List<ManagerResponseDto> findAll(){
        return service.findAll();
    }


    @GetMapping("/full")
    public List<Manager> findAllFull(){
        return service.findFullManagerDetails();
    }

}
