package org.firstspringbootapp39fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringBootApp39FsApplicationTests {

    @Test
    void contextLoads() {
    }

}
