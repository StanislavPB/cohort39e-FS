package org.firstspringbootapp39fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringBootApp39FsApplication {

    public static void main(String[] args) {
        SpringApplication.run(FirstSpringBootApp39FsApplication.class, args);
    }

}
