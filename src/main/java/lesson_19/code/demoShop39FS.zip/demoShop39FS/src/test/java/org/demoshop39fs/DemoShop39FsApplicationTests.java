package org.demoshop39fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoShop39FsApplicationTests {

    @Test
    void contextLoads() {
    }

}
