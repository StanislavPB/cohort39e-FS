//package org.demoshop39fs.service.alternativeService;
//
//import lombok.Data;
//import org.demoshop39fs.dto.CreateRequestUser;
//import org.demoshop39fs.dto.UpdateUserRequest;
//import org.demoshop39fs.dto.UpdateUserRequestForAdmin;
//import org.demoshop39fs.dto.UserResponse;
//import org.demoshop39fs.entity.User;
//import org.demoshop39fs.exceptions.RestException;
//import org.demoshop39fs.repository.UserRepository;
//import org.demoshop39fs.service.ConfirmationCodeService;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Service;
//
//@Data
//
//public class UserService {
//
//    private final UserRepository repository;
//    private final ConfirmationCodeService confirmationCodeService;
//
//
//    public UserResponse registerUser(CreateRequestUser request){
//        if (repository.existsByEmail(request.getEmail())){
//            throw new RestException(HttpStatus.CONFLICT, "Пользователь с email: " + request.getEmail() + " уже зарегистрирован");
//        }
//
//        User user = User.builder()
//                .firstName(request.getFirstName())
//                .lastName(request.getLastName())
//                .email(request.getEmail())
//                .password(request.getPassword()) // пока в открытом виде, но потом будем его хешировать
//                .role(User.Role.USER)
//                .state(User.State.NOT_CONFIRMED)
//                .photoLink(request.getPhotoLink())
//                .build();
//
//        repository.save(user);
//
//        String confirmationCode = confirmationCodeService.createCode(user);
//
//        // потом заменим на отправку по почте
//        System.out.println("Отправили по почте код подтверждения: " + confirmationCode);
//
//        return mapToUserResponse(user);
//    }
//
//
//    public void save(User user){
//        repository.save(user);
//    }
//
//    public UserResponse updateUser(UpdateUserRequest request){
//        User userForUpdate = repository.findById(request.getId())
//                .orElseThrow(() -> new RestException(HttpStatus.NOT_FOUND, "User not found with id " + request.getId()));
//
//        if (request.getPassword() != null) {
//            userForUpdate.setPassword(request.getPassword());
//        }
//
//        if (request.getPhotoLink() != null) {
//            userForUpdate.setPhotoLink(request.getPhotoLink());
//        }
//
//        if (request.getFirstName() != null) {
//            userForUpdate.setFirstName(request.getFirstName());
//        }
//
//        if (request.getLastName() != null) {
//            userForUpdate.setLastName(request.getLastName());
//        }
//
//        repository.save(userForUpdate);
//
//        return mapToUserResponse(userForUpdate);
//    }
//
//    public UserResponse updateUserForAdmin(UpdateUserRequestForAdmin request){
//        User userForUpdate = repository.findById(request.getId())
//                .orElseThrow(() -> new RestException(HttpStatus.NOT_FOUND, "User not found with id " + request.getId()));
//
//        if (request.getPassword() != null) userForUpdate.setPassword(request.getPassword());
//
//        if (request.getPhotoLink() != null) userForUpdate.setPhotoLink(request.getPhotoLink());
//
//        if (request.getFirstName() != null) userForUpdate.setFirstName(request.getFirstName());
//
//        if (request.getLastName() != null) userForUpdate.setLastName(request.getLastName());
//
//        if (request.getRole() != null) userForUpdate.setRole(User.Role.valueOf(request.getRole()));
//
//        if (request.getState() != null) userForUpdate.setState(User.State.valueOf(request.getState()));
//
//        repository.save(userForUpdate);
//
//        return mapToUserResponse(userForUpdate);
//    }
//
//
//    private UserResponse mapToUserResponse(User user) {
//        return UserResponse.builder()
//                .firstName(user.getFirstName())
//                .lastName(user.getLastName())
//                .email(user.getEmail())
//                .role(user.getRole().toString())
//                .state(user.getState().toString())
//                .photoLink(user.getPhotoLink())
//                .build();
//    }
//
//}
