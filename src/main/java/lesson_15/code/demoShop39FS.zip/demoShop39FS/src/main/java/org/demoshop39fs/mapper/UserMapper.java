package org.demoshop39fs.mapper;

import org.demoshop39fs.dto.CreateRequestUser;
import org.demoshop39fs.dto.UpdateUserRequest;
import org.demoshop39fs.dto.UpdateUserRequestForAdmin;
import org.demoshop39fs.dto.UserResponse;
import org.demoshop39fs.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface UserMapper {

    UserResponse toUserResponse(User user);

    void updateUserFromDto(UpdateUserRequest dto, @MappingTarget User user);

    void updateUserFromAdminDto(UpdateUserRequestForAdmin dto, @MappingTarget User user);

    User toEntity(CreateRequestUser request);


}
