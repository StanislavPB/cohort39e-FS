package org.demoshop39fs.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.demoshop39fs.controller.api.AdminApi;
import org.demoshop39fs.dto.UpdateUserRequestForAdmin;
import org.demoshop39fs.dto.UserResponse;
import org.demoshop39fs.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin")
public class AdminController implements AdminApi {

    private final UserService userService;

    @Override
    public ResponseEntity<UserResponse> updateUserForAdmin(@Valid @RequestBody UpdateUserRequestForAdmin request){
        return ResponseEntity.ok(userService.updateUserForAdmin(request));
    }

    @Override
    public ResponseEntity<UserResponse> findUserById(@PathVariable Integer id){
        return ResponseEntity.ok(userService.findById(id));
    }

    @Override
    public ResponseEntity<UserResponse> findUserById(@RequestParam String email){
        return ResponseEntity.ok(userService.findByEmail(email));
    }

    @Override
    public ResponseEntity<List<UserResponse>> findUserByLastName(@RequestParam String lastName){
        return ResponseEntity.ok(userService.findByLastName(lastName));
    }

    @Override
    public ResponseEntity<List<UserResponse>> findUserByFullName(@RequestParam String firstName, @RequestParam String lastName){
        return ResponseEntity.ok(userService.findByLastNameAndFirstName(firstName,lastName));
    }
}
