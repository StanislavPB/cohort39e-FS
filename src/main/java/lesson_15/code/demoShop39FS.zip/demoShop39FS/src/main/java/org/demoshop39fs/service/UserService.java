package org.demoshop39fs.service;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.demoshop39fs.dto.CreateRequestUser;
import org.demoshop39fs.dto.UpdateUserRequest;
import org.demoshop39fs.dto.UpdateUserRequestForAdmin;
import org.demoshop39fs.dto.UserResponse;
import org.demoshop39fs.entity.User;
import org.demoshop39fs.exceptions.RestException;
import org.demoshop39fs.mapper.UserMapper;
import org.demoshop39fs.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Data
@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository repository;
    private final CreateConfirmationCodeService codeService;
    private final UserMapper userMapper;


    public UserResponse registerUser(CreateRequestUser request) {

        checkIfUserExistByEmail(request);

        User user = userMapper.toEntity(request);
        user.setRole(User.Role.USER);
        user.setState(User.State.NOT_CONFIRMED);

        repository.save(user);

        String confirmationCode = codeService.createCode(user);

        // потом заменим на отправку по почте
        System.out.println("Отправили по почте код подтверждения: " + confirmationCode);

        return userMapper.toUserResponse(user);
    }

    private void checkIfUserExistByEmail(CreateRequestUser request) {
        if (repository.existsByEmail(request.getEmail())) {
            throw new RestException(HttpStatus.CONFLICT, "Пользователь с email: " + request.getEmail() + " уже зарегистрирован");
        }
    }


    public void save(User user) {
        repository.save(user);
    }

    public UserResponse updateUser(UpdateUserRequest request) {
        User userForUpdate = getUserByIdOrThrow(request.getId());

        // используем MapStruct для обновления User
        userMapper.updateUserFromDto(request, userForUpdate);

        return saveAndConvertToResponse(userForUpdate);
    }

    public UserResponse updateUserForAdmin(UpdateUserRequestForAdmin request) {
        User userForUpdate = getUserByIdOrThrow(request.getId());

        userMapper.updateUserFromAdminDto(request, userForUpdate);

        return saveAndConvertToResponse(userForUpdate);
    }


    private User getUserByIdOrThrow(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new RestException(HttpStatus.NOT_FOUND, "User not found with id " + id));
    }

    private UserResponse saveAndConvertToResponse(User user) {
        User savedUser = repository.save(user);
        return userMapper.toUserResponse(savedUser);
    }


    // поиск по ID
    public UserResponse findById(Integer id) {
        return userMapper.toUserResponse(getUserByIdOrThrow(id));
    }

    // поиск по email
    public UserResponse findByEmail(String email) {
        User foundUser = repository.findByEmail(email)
                .orElseThrow(() -> new RestException(HttpStatus.NOT_FOUND, "User not found with email " + email));
        return userMapper.toUserResponse(foundUser);
    }


    // поиск по фамилии

    public List<UserResponse> findByLastName(String lastName) {
        List<User> users = repository.findByLastName(lastName);
        return users.stream()
                .map(userMapper::toUserResponse)
                .toList();
    }


    // поиск по фамилии и имени

    public List<UserResponse> findByLastNameAndFirstName(String firstName, String lastName) {
        List<User> users = repository.findByLastNameAndFirstName(lastName, firstName);
        return users.stream()
                .map(userMapper::toUserResponse)
                .toList();
    }

}
