package org.demoshop39fs.controller.api;
import jakarta.validation.Valid;
import org.demoshop39fs.dto.UpdateUserRequestForAdmin;
import org.demoshop39fs.dto.UserResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public interface AdminApi {

    @PutMapping("/update")
    public ResponseEntity<UserResponse> updateUserForAdmin(@Valid @RequestBody UpdateUserRequestForAdmin request);


    @GetMapping("/find/{id}")
    public ResponseEntity<UserResponse> findUserById(@PathVariable Integer id);


    @GetMapping("/find") // /find?email=admin@company.com
    public ResponseEntity<UserResponse> findUserById(@RequestParam String email);


    @GetMapping("/findByLastName")
    public ResponseEntity<List<UserResponse>> findUserByLastName(@RequestParam String lastName);


    @GetMapping("/findByFullName")
    public ResponseEntity<List<UserResponse>> findUserByFullName(@RequestParam String firstName, @RequestParam String lastName);

}
