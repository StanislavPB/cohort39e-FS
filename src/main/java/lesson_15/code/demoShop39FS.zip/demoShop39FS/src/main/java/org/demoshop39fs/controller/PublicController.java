package org.demoshop39fs.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.demoshop39fs.controller.api.PublicApi;
import org.demoshop39fs.dto.CreateRequestUser;
import org.demoshop39fs.dto.UserResponse;
import org.demoshop39fs.service.ConfirmationCodeService;
import org.demoshop39fs.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/public")
@RequiredArgsConstructor
public class PublicController implements PublicApi {

    private final UserService userService;
    private final ConfirmationCodeService confirmationCodeService;

    @Override
    public ResponseEntity<UserResponse> registerUser(@Valid @RequestBody CreateRequestUser request) {
        UserResponse response = userService.registerUser(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<UserResponse> confirmUser(@RequestParam String confirmationCode) {
        UserResponse response = confirmationCodeService.confirm(confirmationCode);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
