package org.demoshop39fs.controller.api;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.demoshop39fs.controller.api.PublicApi;
import org.demoshop39fs.dto.CreateRequestUser;
import org.demoshop39fs.dto.UserResponse;
import org.demoshop39fs.service.ConfirmationCodeService;
import org.demoshop39fs.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/public")
public interface PublicApi {

    @PostMapping("/register")
    public ResponseEntity<UserResponse> registerUser(@Valid @RequestBody CreateRequestUser request) ;

    @PostMapping("/confirm")
    public ResponseEntity<UserResponse> confirmUser(@RequestParam String confirmationCode);

}
