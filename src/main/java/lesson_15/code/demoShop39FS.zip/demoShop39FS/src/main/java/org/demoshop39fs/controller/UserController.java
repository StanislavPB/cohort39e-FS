package org.demoshop39fs.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.demoshop39fs.controller.api.UserApi;
import org.demoshop39fs.dto.UpdateUserRequest;
import org.demoshop39fs.dto.UserResponse;
import org.demoshop39fs.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController implements UserApi {

    private final UserService userService;

    @Override
    public ResponseEntity<UserResponse> updateUser(@Valid @RequestBody UpdateUserRequest request){
        return ResponseEntity.ok(userService.updateUser(request));
    }
}
