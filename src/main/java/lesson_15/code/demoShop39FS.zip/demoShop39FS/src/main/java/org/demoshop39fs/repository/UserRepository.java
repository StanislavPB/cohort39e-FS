package org.demoshop39fs.repository;

import org.demoshop39fs.entity.ConfirmationCode;
import org.demoshop39fs.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Integer> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    Optional<User> findFirstByConfirmationCode(ConfirmationCode code);

    List<User> findByLastName(String lastName);

    List<User> findByLastNameAndFirstName(String lastName, String firstName);
}
