package org.demospringsecuritythymeleafapp39fs.springConfiguratiionVersion2;

public class SecurityConfigSpringVersion2 {}
////public class SecurityConfigSpringVersion2 extends WebSecurityConfigurerAdapter {
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return NoOpPasswordEncoder.getInstance();
//    }
//
//    @Override
//    public void configure(AuthenticationManagerBuilder auth) throws Exception {
//        auth.inMemoryAuthentication()
//                .withUser("user")
//                .password("user")
//                .authorities("ROLE_USER")
//                .and()
//                .withUser("admin")
//                .password("admin")
//                .authorities("ROLE_ADMIN");
//    }
//
//    @Override
//    protected void configure(HttpSecurity http) throws Exception {
//      http.authorizeRequests()
//              .antMatchers("/admin/**").hasRole("ADMIN")
//              .antMatchers("/user/**").hasAnyRole("USER","ADMIN")
//              .antMatchers("/**").permitAll()
//              .and()
//              .formLogin();
//    }
