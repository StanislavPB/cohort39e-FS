package org.demospringsecuritythymeleafapp39fs.service;

import lombok.AllArgsConstructor;
import org.demospringsecuritythymeleafapp39fs.dto.UserRegistrationDto;
import org.demospringsecuritythymeleafapp39fs.entity.Role;
import org.demospringsecuritythymeleafapp39fs.entity.User;
import org.demospringsecuritythymeleafapp39fs.repository.RoleRepository;
import org.demospringsecuritythymeleafapp39fs.repository.UserRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

@Service
@AllArgsConstructor
public class UserService implements UserServiceInterface{

    private UserRepository repository;
    private RoleRepository roleRepository;


    @Override
    public User save(UserRegistrationDto registrationDto) {
        Role defaultRole = roleRepository.findByName("ROLE_USER");

        var user = new User(
                registrationDto.getFirstName(),
                registrationDto.getLastName(),
                registrationDto.getEmail(),
                registrationDto.getPassword(),
                Arrays.asList(defaultRole)
        );
        return repository.save(user);
    }

    @Override
    public List<User> getAll() {
        return repository.findAll();
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        var userOptional = repository.findByEmail(email);

        if (userOptional.isEmpty()) {
            throw new UsernameNotFoundException("Invalid username");
        }

        var user = userOptional.get();
        return new org.springframework.security.core.userdetails.User(
                user.getEmail(),
                user.getPassword(),
                mapRolesToAuthorities(user.getRoles()));
    }

    private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles) {
        return roles.stream()
                .map(role -> new SimpleGrantedAuthority(role.getName()))
                .toList();
    }
}
