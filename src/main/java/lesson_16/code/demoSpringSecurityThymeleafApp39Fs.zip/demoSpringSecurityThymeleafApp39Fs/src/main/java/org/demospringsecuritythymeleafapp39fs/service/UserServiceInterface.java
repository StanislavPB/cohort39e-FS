package org.demospringsecuritythymeleafapp39fs.service;

import org.demospringsecuritythymeleafapp39fs.dto.UserRegistrationDto;
import org.demospringsecuritythymeleafapp39fs.entity.User;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserServiceInterface extends UserDetailsService {

    User save(UserRegistrationDto registrationDto);

    List<User> getAll();
}
