package org.demospringsecuritythymeleafapp39fs.springConfiguratiionVersion2;

import org.springframework.web.bind.annotation.GetMapping;


public class HelloController {

    @GetMapping("/")
    public String hello() {
        return "Hello";
    }

    @GetMapping("/user")
    public String user(){
        return "User";
    }

    @GetMapping("/admin")
    public String admin(){
        return "Admin";
    }
}
