package org.demospringsecuritythymeleafapp39fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringSecurityThymeleafApp39FsApplicationTests {

    @Test
    void contextLoads() {
    }

}
