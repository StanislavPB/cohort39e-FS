package org.demospringsecuritythymeleafapp39fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringSecurityThymeleafApp39FsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoSpringSecurityThymeleafApp39FsApplication.class, args);
    }

}
