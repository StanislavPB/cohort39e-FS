package org.demoshop39fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoShop39FsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoShop39FsApplication.class, args);
    }

}
